async function clearSession(page) {
  await page.evaluate(() => {
    localStorage.removeItem('editor.session.v1');
  });
}

module.exports = { clearSession };