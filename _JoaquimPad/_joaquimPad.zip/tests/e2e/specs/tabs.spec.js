const { test, expect } = require('@playwright/test');
const { launchApp } = require('../setup/electronApp');

test('cria, alterna, fecha e restaura abas corretamente', async () => {
  let { app, page } = await launchApp({
    initScript: () => {
      localStorage.removeItem('editor.session.v1');
    },
  });

  /* =========================
     ESTADO INICIAL
     ========================= */
  let tabs = page.locator('#tabs .tab');
  const initialCount = await tabs.count();

  // ✅ SEMPRE >= 1
  expect(initialCount).toBeGreaterThanOrEqual(1);

  /* =========================
     CRIA NOVA ABA
     ========================= */
  await page.click('#newTabBtn');

  tabs = page.locator('#tabs .tab');
  await expect(tabs).toHaveCount(initialCount + 1);
  await expect(tabs.last()).toHaveClass(/active/);

  /* =========================
     CRIA OUTRA ABA
     ========================= */
  await page.click('#newTabBtn');

  tabs = page.locator('#tabs .tab');
  await expect(tabs).toHaveCount(initialCount + 2);
  await expect(tabs.last()).toHaveClass(/active/);

  /* =========================
     ALTERNA PARA ABA ANTERIOR
     ========================= */
  await tabs.nth(initialCount).click();
  await expect(tabs.nth(initialCount)).toHaveClass(/active/);

  /* =========================
     FECHA ABA ATIVA
     ========================= */
  await tabs.nth(initialCount).locator('.close').click();

  tabs = page.locator('#tabs .tab');
  await expect(tabs).toHaveCount(initialCount + 1);

  /* =========================
     FECHA APP
     ========================= */
  await app.close();

  /* =========================
     SEGUNDA EXECUÇÃO (RESTORE)
     ========================= */
  ({ app, page } = await launchApp());

  tabs = page.locator('#tabs .tab');
  await expect(tabs).toHaveCount(initialCount + 1);

  await app.close();
});