const { test, expect } = require('@playwright/test');
const os = require('os');
const path = require('path');
const { launchApp } = require('../setup/electronApp');

test('Fase 1 — inicia com Desktop e mantém expansão entre sessões', async () => {
  const DESKTOP = path.join(os.homedir(), 'Desktop');

  /* =========================
     PRIMEIRA EXECUÇÃO
     ========================= */
  let { app, page } = await launchApp({
    initScript: (desktop) => {
      localStorage.setItem(
        'editor.session.v1',
        JSON.stringify({
          version: 1,
          projectRoot: desktop,
          expandedFolders: [desktop],
          tabs: [],
          activeTabId: null,
          cursorHistory: null,
        })
      );
    },
    initArg: DESKTOP,
  });

  /* =========================
     TREEVIEW VISÍVEL
     ========================= */
  const tree = page.locator('#fileExplorer');
  await expect(tree).toBeVisible({ timeout: 10_000 });

  /* =========================
     EXPANDE PASTA SE EXISTIR
     ========================= */
  const folders = page.locator('#fileExplorer li.folder > .explorer-row');
  const count = await folders.count();

  if (count > 0) {
    const folder = folders.first();
    await folder.click();

    const children = folder.locator('xpath=..//ul');
    await expect(children).toBeVisible({ timeout: 10_000 });
  }

  /* =========================
     FECHA APP
     ========================= */
  await app.close();

  /* =========================
     SEGUNDA EXECUÇÃO (RESTORE)
     ========================= */
  ({ app, page } = await launchApp());

  const restoredTree = page.locator('#fileExplorer');
  await expect(restoredTree).toBeVisible();

  const restoredFolders = page.locator('#fileExplorer li.folder > ul');

  if (await restoredFolders.count() > 0) {
    await expect(restoredFolders.first()).toBeVisible();
  }

  await app.close();
});