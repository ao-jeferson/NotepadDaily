const { test, expect } = require('@playwright/test');
const { launchApp } = require('../setup/electronApp');

test('aba pinada não fecha e persiste na sessão', async () => {
  let { app, page } = await launchApp({
    initScript: () => {
      localStorage.removeItem('editor.session.v1');
    },
  });

  // cria duas abas
  await page.click('#newTabBtn');
  await page.click('#newTabBtn');

  const tabs = page.locator('#tabs .tab');
  await expect(tabs).toHaveCount(2);

  // pinar a primeira (menu de contexto ou botão se existir)
  await tabs.first().click({ button: 'right' });
  await page.getByText(/Pin/i).click();

  await expect(tabs.first()).toHaveClass(/pinned/);

  // tenta fechar a aba pinada
  const closeBtn = tabs.first().locator('.close');
  await closeBtn.click({ force: true });

  // NÃO fechou
  await expect(page.locator('#tabs .tab')).toHaveCount(2);

  // fecha o app
  await app.close();

  // reabre
  ({ app, page } = await launchApp());

  // aba pinada ainda existe
  const restoredTabs = page.locator('#tabs .tab');
  await expect(restoredTabs.first()).toHaveClass(/pinned/);

  await app.close();
});
