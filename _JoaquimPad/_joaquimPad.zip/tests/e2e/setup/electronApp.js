const { _electron: electron } = require('playwright');

async function launchApp(options = {}) {
  const app = await electron.launch({
    args: ['.'],
    env: {
      ...process.env,
      E2E: 'true',
    },
  });

  const page = await app.firstWindow();

  if (options.initScript) {
    await page.addInitScript(options.initScript, options.initArg);
  }

  await page.waitForLoadState('domcontentloaded');

  return { app, page };
}

module.exports = { launchApp };