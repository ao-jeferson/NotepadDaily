const { Menu } = require("electron");
const path = require("path");

function getIcon(name) {
  return path.join(__dirname, "..", "assets", "icons", `${name}.png`);
}

function createMenu({ mainWindow, currentLanguage }) {
  if (!mainWindow) return null;

  const LANGUAGES = [
    { id: "plaintext", label: "Plain Text", icon: "plain" },
    { type: "separator" },
    { id: "javascript", label: "JavaScript", icon: "js" },
    { id: "typescript", label: "TypeScript", icon: "ts" },
    { type: "separator" },
    { id: "python", label: "Python", icon: "python" },
    { id: "csharp", label: "C#" },
    { id: "java", label: "Java" },
    { type: "separator" },
    { id: "sql", label: "SQL" },
    { id: "json", label: "JSON" },
  ];

  const languageMenu = LANGUAGES.map(item => {
    if (item.type === "separator") return item;

    return {
      label: item.label,
      type: "radio",
      checked: currentLanguage === item.id,
      icon: item.icon ? getIcon(item.icon) : undefined,
      click: () => {
        mainWindow.webContents.send("menu:view:setLanguage", item.id);
      }
    };
  });

  const template = [
    {
      label: "Arquivo",
      submenu: [
        {
          label: "Novo",
          accelerator: "Ctrl+N",
          click: () => mainWindow.webContents.send("menu:file:new")
        },
        {
          label: "Abrir…",
          accelerator: "Ctrl+O",
          click: () => mainWindow.webContents.send("menu:file:open")
        },
        {
          label: "Salvar",
          accelerator: "Ctrl+S",
          click: () => mainWindow.webContents.send("menu:file:save")
        },
        { type: "separator" },
        { role: "quit" }
      ]
    },
    {
      label: "Linguagem",
      submenu: languageMenu
    },
    {
      label: "Janela",
      submenu: [
        { role: "reload" },
        { role: "toggleDevTools" },
        { type: "separator" },
        { role: "togglefullscreen" }
      ]
    }
  ];

  return Menu.buildFromTemplate(template);
}

module.exports = { createMenu };