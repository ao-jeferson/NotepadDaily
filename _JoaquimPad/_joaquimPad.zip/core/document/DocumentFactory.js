// core/document/DocumentFactory.js

export function createDocument({
  id,
  filePath = null,
  displayName,
  content = "",
  language = "plaintext",
  icon = "plain",
  dirty = false,
  languageManuallySet = false,
}) {
  const changeListeners = new Set();

  return {
    id,
    filePath,
    displayName,
    content,
    language,
    icon,
    dirty,
    languageManuallySet,
    /* ===== CONTRATO DO DOCUMENT ===== */

    getContent() {
      return this.content;
    },

    setContent(value) {
      this.content = value;
      this.dirty = true;
      changeListeners.forEach((cb) => cb(this));
    },

    isDirty() {
      return this.dirty;
    },

    onChange(cb) {
      changeListeners.add(cb);
      return () => changeListeners.delete(cb);
    },

    getSizeInBytes() {
      return new TextEncoder().encode(this.content || "").length;
    },

    getFileName() {
      if (this.displayName && this.displayName.trim()) {
        return this.displayName;
      }

      if (this.filePath) {
        return this.filePath.split(/[\\/]/).pop();
      }

      return "Untitled";
    },
    setLanguage(lang) {
      this.language = lang;
    },

    toJSON() {
      return {
        id: this.id,
        filePath: this.filePath,
        displayName: this.displayName,
        language: this.language,
        languageManuallySet: this.languageManuallySet, // ✅
        icon: this.icon,
        dirty: this.dirty,
        content: this.content,
      };
    },
  };
}
export function ensureDocumentContract(doc) {
  if (typeof doc?.toJSON === "function") {
    return doc;
  }

  return createDocument({
    id: doc.id,
    filePath: doc.filePath ?? null,
    displayName: doc.displayName ?? "Untitled",
    content: doc.content ?? "",
    language: doc.language ?? "plaintext",
    languageManuallySet: doc.languageManuallySet ?? false, // ✅
    icon: doc.icon ?? "plain",
    dirty: doc.dirty ?? false,
  });
}
