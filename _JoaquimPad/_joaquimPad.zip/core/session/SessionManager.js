const SESSION_KEY = "editor.session.v1";

export default class SessionManager {
  /* =========================
     SALVAR SESSÃO
     ========================= */
  saveSnapshot(snapshot) {
    try {
      localStorage.setItem(SESSION_KEY, JSON.stringify(snapshot));
    } catch (err) {
      console.error("Erro ao salvar sessão:", err);
    }
  }

  /* =========================
     CARREGAR SESSÃO
     ========================= */
  loadSnapshot() {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;

      const data = JSON.parse(raw);

      // ✅ garante estrutura mínima
      return {
        version: data.version ?? 1,

        projectRoot: data.projectRoot ?? null,
        expandedFolders: data.expandedFolders ?? [],
        activeFilePath: data.activeFilePath ?? null,

        tabs: data.tabs ?? [],
        activeTabId: data.activeTabId ?? null,

        cursorHistory: data.cursorHistory ?? null,
      };
    } catch (err) {
      console.error("Erro ao carregar sessão:", err);
      return null;
    }
  }

  /* =========================
     LIMPAR SESSÃO
     ========================= */
  clear() {
    localStorage.removeItem(SESSION_KEY);
  }
}