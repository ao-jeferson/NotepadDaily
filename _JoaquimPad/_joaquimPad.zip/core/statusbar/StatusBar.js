export class StatusBar {
  constructor(EditorCore) {
    this.EditorCore = EditorCore;

    this.elLineCol = document.getElementById("status-linecol");
    this.elSelection = document.getElementById("status-selection");
    this.elFileSize = document.getElementById("status-size");
    this.elLanguage = document.getElementById("status-language");

    this._cursorDisposable = null;
    this._selectionDisposable = null;
  }

  init() {
    // nada aqui — o bind acontece por documento
  }

  /* =====================================================
     BIND DOCUMENT (chamado ao trocar de aba)
     ===================================================== */
  bindDocument(doc) {
    this._detachEditorListeners();

    if (!doc) {
      this._clear();
      return;
    }

    this._updateLanguage(doc);
    this._updateFileSize(doc);

    this._attachEditorListeners();
  }

  /* =====================================================
     EDITOR LISTENERS
     ===================================================== */
  _attachEditorListeners() {
    const editor = this.EditorCore.getEditor();
    if (!editor) return;

    this._cursorDisposable = editor.onDidChangeCursorPosition((e) => {
      this._updatePosition(e.position);
    });

    this._selectionDisposable = editor.onDidChangeCursorSelection((e) => {
      this._updateSelection(e.selection);
    });

    // força atualização inicial
    const pos = editor.getPosition();
    const sel = editor.getSelection();

    if (pos) this._updatePosition(pos);
    if (sel) this._updateSelection(sel);
  }

  _detachEditorListeners() {
    this._cursorDisposable?.dispose();
    this._selectionDisposable?.dispose();

    this._cursorDisposable = null;
    this._selectionDisposable = null;
  }

  /* =====================================================
     UPDATERS
     ===================================================== */

  _updatePosition(position) {
    if (!this.elLineCol || !position) return;

    this.elLineCol.textContent = `Ln ${position.lineNumber} · Col ${position.column}`;
  }

  _updateSelection(selection) {
    if (!this.elSelection) return;

    if (!selection || selection.isEmpty()) {
      this.elSelection.textContent = "";
      return;
    }

    const chars =
      Math.abs(
        (selection.endLineNumber - selection.startLineNumber) * 1000 +
          (selection.endColumn - selection.startColumn),
      ) || 0;

    this.elSelection.textContent = chars === 1 ? "1 char" : `${chars} chars`;
  }

  _formatBytes(bytes) {
    if (bytes === 0) return "0 B";

    const k = 1024;
    const units = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));

    const value = bytes / Math.pow(k, i);
    return `${value.toFixed(value < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
  }

  _updateFileSize(doc) {
    if (!this.elFileSize) return;

    const content = doc.getContent?.() ?? "";
    const bytes = new Blob([content]).size;

    this.elFileSize.textContent = this._formatBytes(bytes);
  }

  _updateLanguage(doc) {
    if (!this.elLanguage) return;

    const label = doc.languageManuallySet
      ? `${doc.language} (manual)`
      : doc.language;

    this.elLanguage.textContent = label;
  }

  /* =====================================================
     CLEAR
     ===================================================== */
  _clear() {
    this.elLineCol && (this.elLineCol.textContent = "");
    this.elSelection && (this.elSelection.textContent = "");
    this.elFileSize && (this.elFileSize.textContent = "");
    this.elLanguage && (this.elLanguage.textContent = "");
  }
}
