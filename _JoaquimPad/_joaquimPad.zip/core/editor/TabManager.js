import { Document } from "../document/Document.js";
import {  createDocument, ensureDocumentContract,} from "../document/DocumentFactory.js";

function formatNow() {
  const d = new Date();

  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const min = String(d.getMinutes()).padStart(2, "0");

  return `${dd}-${mm} ${hh}-${min}`;
}

export default class TabManager {
  constructor({ container, onActivate, cursorNav, languageIcons }) {
    this.container = container;
    this.onActivate = onActivate;
    this.cursorNav = cursorNav;
    this.languageIcons = languageIcons;

    this.tabs = [];
    this.active = null;
  }

  /* =====================================================
     RENDER TABS (PINNED À ESQUERDA)
     ===================================================== */
  renderTabs() {
    const tabContainer = this.container;
    const { onActivate, cursorNav, languageIcons } = this;

    tabContainer.innerHTML = "";

    const pinnedTabs = this.tabs.filter((t) => t.pinned);
    const normalTabs = this.tabs.filter((t) => !t.pinned);
    const orderedTabs = [...pinnedTabs, ...normalTabs];

    orderedTabs.forEach((doc) => {
      const tab = document.createElement("div");
      tab.className = "tab";

      if (doc === this.active) tab.classList.add("active");
      if (doc.pinned) tab.classList.add("pinned");

      const btn = document.createElement("button");
      btn.type = "button";

      /* =====================
       ÍCONE (PRIORIDADE)
       pinned > file > language > desconhecido
       ===================== */
      let iconKey;

      if (doc.pinned) {
        iconKey = "pinned";
      } else if (doc.icon === "file") {
        iconKey = "file";
      } else if (languageIcons[doc.language]) {
        iconKey = languageIcons[doc.language];
      } else {
        iconKey = "fileadd";
      }

      const icon = document.createElement("img");
      icon.src = `./assets/icons/${iconKey}.png`;
      icon.className = "tab-icon";
      btn.appendChild(icon);

      const title = document.createElement("span");
      title.className = "tab-title";
      title.textContent = doc.getFileName();
      btn.appendChild(title);

      if (doc.isDirty()) {
        const dot = document.createElement("span");
        dot.className = "modified-dot";
        btn.appendChild(dot);
      }

      btn.onclick = () => onActivate(doc);

      btn.onmousedown = (e) => {
        if (e.button === 1 && !doc.pinned) {
          e.preventDefault();
          this.close(doc);
        }
      };

      tab.appendChild(btn);

      if (!doc.pinned) {
        const close = document.createElement("span");
        close.className = "close";
        close.textContent = "×";

        close.onclick = (e) => {
          e.stopPropagation();
          this.close(doc); // ✅ NUNCA doc.id
        };

        tab.appendChild(close);
      }

      tab.oncontextmenu = (e) => {
        e.preventDefault();
        this.showContextMenu(e.clientX, e.clientY, doc);
      };

      tabContainer.appendChild(tab);
    });

    this.setupSortable();
  }

  showContextMenu(x, y, doc) {
    // remove menu anterior se existir
    document.querySelector(".tab-context-menu")?.remove();

    const menu = document.createElement("div");
    menu.className = "tab-context-menu";
    menu.style.left = `${x}px`;
    menu.style.top = `${y}px`;

    menu.innerHTML = `
    <div class="item">${doc.pinned ? "Unpin Tab" : "Pin Tab"}</div>
    ${doc.pinned ? "" : "<div class='item'>Fechar</div>"}
    <div class="item">Fechar outras</div>
  `;

    let i = 0;

    /* =========================
     Pin / Unpin
     ========================= */
    menu.children[i++].onclick = () => {
      doc.pinned = !doc.pinned;

      // pinadas sempre à esquerda
      this.tabs = [
        ...this.tabs.filter((t) => t.pinned),
        ...this.tabs.filter((t) => !t.pinned),
      ];

      this.renderTabs();

      menu.remove();
    };

    /* =========================
     Fechar
     ========================= */
    if (!doc.pinned) {
      menu.children[i++].onclick = () => {
        this.close(doc);
        menu.remove();
      };
    }

    /* =========================
     Fechar outras
     ========================= */

    menu.children[i].onclick = () => {
      this.tabs
        .filter((t) => t !== doc && !t.pinned)
        .forEach((t) => this.close(t));

      menu.remove();
    };

    document.body.appendChild(menu);

    // fecha menu ao clicar fora
    setTimeout(() => {
      document.addEventListener("click", () => menu.remove(), { once: true });
    }, 0);
  }

  /* =====================================================
     ✅ LIMPEZA AO FECHAR ABA
     ===================================================== */
  onTabClosed(tabId) {
    this.backStack = this.backStack.filter((h) => h.docId !== tabId);

    this.forwardStack = this.forwardStack.filter((h) => h.docId !== tabId);

    this._emitState();
  }

  close(doc) {
    if (!doc) return;

    const index = this.tabs.indexOf(doc);
    if (index === -1) {
      console.warn("Tentativa de fechar aba não encontrada:", doc);
      return;
    }

    const wasActive = doc === this.active;

    // remove a aba
    this.tabs.splice(index, 1);

    // define novo ativo
    if (wasActive) {
      this.active =
        this.tabs[index] ||
        this.tabs[index - 1] ||
        this.tabs[this.tabs.length - 1] ||
        null;
    }

    // re-renderiza as abas
    this.renderTabs();

    // notifica cursor navigation (se existir)
    this.cursorNav?.onTabClosed?.(doc.id);

    // ativa o novo documento
    if (this.active) {
      this.onActivate?.(this.active);
    }

    // salva sessão
  }

  setCursorNavigation(cursorNav) {
    this.cursorNav = cursorNav;
  }

  setupSortable() {
    if (!window.Sortable) return;

    // destrói instância anterior
    if (this.sortable) {
      this.sortable.destroy();
      this.sortable = null;
    }

    this.sortable = Sortable.create(this.container, {
      animation: 150,
      ghostClass: "sortable-ghost",
      chosenClass: "sortable-chosen",
      filter: ".pinned",
      preventOnFilter: false,

      onEnd: ({ oldIndex, newIndex }) => {
        const allTabs = this.tabs.filter(Boolean);

        const pinned = allTabs.filter((t) => t.pinned);
        const normal = allTabs.filter((t) => !t.pinned);

        const pinnedCount = pinned.length;

        let from = oldIndex - pinnedCount;
        let to = newIndex - pinnedCount;

        if (from < 0 || to < 0) {
          this.renderTabs();
          return;
        }

        if (from >= normal.length || to > normal.length) {
          this.renderTabs();
          return;
        }

        const moved = normal[from];
        if (!moved) {
          this.renderTabs();
          return;
        }

        const newNormal = normal.toSpliced(from, 1).toSpliced(to, 0, moved);

        // ✅ pinadas continuam à esquerda
        this.tabs = [...pinned, ...newNormal];

        this.renderTabs();
      },
    });
  }
  /* =========================
     Snapshot para sessão
     ========================= */

  // Arquivo: TabManager.js
  // Método: getSnapshot()

getSnapshot() {
  return {
    activeTabId: this.active?.id ?? null,
    tabs: this.tabs.map((doc) => ({
      id: doc.id,
      filePath: doc.filePath ?? null,
      displayName: doc.displayName ?? null,
      language: doc.language ?? "plaintext",
      languageManuallySet: !!doc.languageManuallySet,
      pinned: !!doc.pinned,
      content: doc.filePath ? undefined : doc.getContent(),
      editorState: doc._editorState ?? null,
    })),
  };
}

  async restoreSnapshot(snapshot) {
    this.tabs = [];

    for (const data of snapshot.tabs) {
      const doc = new Document({
        id: data.id,
        filePath: data.filePath ?? null,
        content: data.content ?? "",
        language: data.language ?? "plaintext",
        displayName: data.displayName,
        pinned: !!data.pinned,
        languageManuallySet: !!data.languageManuallySet,
      });

      this.tabs.push(doc);
    }
    this.active = this.tabs.find((t) => t.id === snapshot.activeTabId) ?? null;
    this.renderTabs();
  }

  createNew(name) {
    const doc = createDocument({
      id: crypto.randomUUID(),
      displayName: name,
      content: "",
      language: "plaintext",
      icon: "file",
      dirty: false,
    });

    this.tabs.push(doc);
    this.setActive(doc);

    return doc;
  }

  restoreTab(json) {
    return createDocument(json);
  }

  open(doc) {
    const normalized = ensureDocumentContract(doc);
    this.tabs.push(normalized);
    this.setActive(normalized);
  }

  getActive() {
    return this.active;
  }

  setActive(doc) {
    if (!doc) return;
    if (this.active === doc) return;
    this.active = doc;
    this.renderTabs();
    this.onActivate?.(doc);
  }

  switchTo(id) {
    const doc = this.tabs.find((d) => d.id === id);
    if (doc) this.setActive(doc);
  }

  close(doc) {
    if (!doc) return;

    const index = this.tabs.indexOf(doc);
    if (index === -1) return;

    const wasActive = doc === this.active;

    this.tabs.splice(index, 1);

    if (wasActive) {
      this.active =
        this.tabs[index] ||
        this.tabs[index - 1] ||
        this.tabs[this.tabs.length - 1] ||
        null;
    }

    this.renderTabs();

    this.cursorNav?.onTabClosed?.(doc.id);

    if (this.active) {
      this.onActivate?.(this.active);
    }
  }

  move(draggedId, targetId) {
    const from = this.tabs.findIndex((d) => d.id === draggedId);
    const to = this.tabs.findIndex((d) => d.id === targetId);
    if (from === -1 || to === -1) return;

    const [doc] = this.tabs.splice(from, 1);
    this.tabs.splice(to, 0, doc);
  }
}
