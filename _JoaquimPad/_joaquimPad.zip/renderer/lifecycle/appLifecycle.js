export function bindLifecycle(saveSession) {
  window.addEventListener("beforeunload", saveSession);

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
      saveSession();
    }
  });

  window.appLifecycle?.onBeforeQuit(saveSession);

  window.addEventListener("unhandledrejection", (event) => {
    const reason = event.reason;

    // Monaco Editor cancela promises internamente (comportamento normal)
    if (
      reason === "Canceled" ||
      (reason instanceof Error &&
        reason.message === "Canceled" &&
        event.promise)
    ) {
      event.preventDefault();
      return;
    }

    // ✅ deixe outros erros passarem
    console.error("Unhandled rejection:", reason);
  });
}
