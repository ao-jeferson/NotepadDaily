export function createSessionController({
  session,
  tabManager,
  EditorCore,
}) {
  return {
    save({ projectRoot, expandedFolderPaths, activeFilePath }) {
      const editor = EditorCore.getEditor();
      const model = editor?.getModel();
      const activeDoc = tabManager.getActive();

      if (model && activeDoc) {
        activeDoc.setContent(model.getValue());
        activeDoc._editorState = {
          position: editor.getPosition(),
          selection: editor.getSelection(),
        };
      }

      session.saveSnapshot({
        projectRoot,
        expandedFolders: Array.from(expandedFolderPaths),
        activeFilePath,
        activeTabId: tabManager.getActive()?.id ?? null,
        ...tabManager.getSnapshot(),
      });
    },

    load() {
      return session.loadSnapshot();
    },
  };
}