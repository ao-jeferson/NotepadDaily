export function createFileExplorer({
  container,
  fsService,
  onOpenFile,
  onStateChange,
}) {
  let expandedPaths = new Set();

  function render(tree, expanded = []) {
    expandedPaths = new Set(expanded);
    container.innerHTML = "";
    container.appendChild(renderNode(tree, 0));
  }

  function renderNode(nodes, level) {
    const ul = document.createElement("ul");
    ul.className = "explorer-list";

    nodes.forEach((node) => {
      const li = document.createElement("li");
      li.classList.add("explorer-item", node.type);
      li.style.paddingLeft = `${level * 14 + 8}px`;

      const row = document.createElement("div");
      row.className = "explorer-row";

      /* ===== ÍCONE ===== */
      const icon = document.createElement("img");
      icon.className = "explorer-icon";
      icon.src =
        node.type === "folder"
          ? "../renderer/assets/icons/folder.png"
          : "../renderer/assets/icons/file.png";

      row.appendChild(icon);

      /* ===== TEXTO ===== */
      const label = document.createElement("span");
      label.className = "explorer-label";
      label.textContent = node.name;
      row.appendChild(label);

      li.appendChild(row);

      /* ===== PASTA ===== */
      if (node.type === "folder") {
        const children = renderNode(node.children || [], level + 1);
        const expanded = expandedPaths.has(node.path);

        children.style.display = expanded ? "block" : "none";
        li.classList.toggle("expanded", expanded);

        row.onclick = () => {
          const open = children.style.display === "none";
          children.style.display = open ? "block" : "none";

          open
            ? expandedPaths.add(node.path)
            : expandedPaths.delete(node.path);

          li.classList.toggle("expanded", open);
          onStateChange?.(new Set(expandedPaths));
        };

        li.appendChild(children);
      }

      /* ===== ARQUIVO ===== */
      if (node.type === "file") {
        row.ondblclick = () => onOpenFile(node.path);
      }

      ul.appendChild(li);
    });

    return ul;
  }

  return { render };
}