export function resolveDom() {
  return {
    editorContainer: document.getElementById("editor"),
    tabContainer: document.getElementById("tabs"),
    newTabBtn: document.getElementById("newTabBtn"),
    backBtn: document.getElementById("cursorBack"),
    forwardBtn: document.getElementById("cursorForward"),
    fileExplorer: document.getElementById("fileExplorer"),
    sidebar: document.getElementById("sidebar"),
    sidebarResizer: document.getElementById("sidebar-resizer"),
  };
}
