import { EditorCore } from "../../core/editor/EditorCore.js";
import TabManager from "../../core/editor/TabManager.js";
import { FileSystemService } from "../../core/filesystem/FileSystemService.js";
import SessionManager from "../../core/session/SessionManager.js";
import { StatusBar } from "../../core/statusbar/StatusBar.js";

export function bootstrapCore(dom, languageIcons) {
  EditorCore.init(dom.editorContainer);

  const tabManager = new TabManager({
    container: dom.tabContainer,
    languageIcons,
  });

  const fsService = new FileSystemService();
  const session = new SessionManager();

  const statusBar = new StatusBar(EditorCore);
  statusBar.init();

  return {
    EditorCore,
    tabManager,
    fsService,
    session,
    statusBar,
  };
}