import { ensureDocumentContract } from "../../core/document/DocumentFactory.js";

export function createDocumentActivator({
  tabManager,
  fsService,
  EditorCore,
  statusBar,
  cursorNav,
}) {
  return async function activateDocument(doc) {
    if (!doc) return;

    let finalDoc = doc;

    /* =========================================
       1. REABRE DO DISCO SE NECESSÁRIO
       PRIORIDADE: filePath > content
       ========================================= */
    if (doc.filePath) {
      try {
        const reopened = await fsService.openFileFromPath(doc.filePath, {
          id: doc.id,
        });

        // preserva metadados da aba
        reopened.pinned = doc.pinned;
        reopened.language = doc.language;
        reopened.languageManuallySet = doc.languageManuallySet;
        reopened._editorState = doc._editorState;

        const index = tabManager.tabs.indexOf(doc);
        if (index !== -1) {
          tabManager.tabs[index] = reopened;
        }

        finalDoc = reopened;
      } catch (err) {
        console.warn(
          "Falha ao reabrir arquivo pelo filePath, mantendo doc em memória:",
          doc.filePath,
          err
        );
      }
    }

    /* =========================================
       2. NORMALIZA CONTRATO
       ========================================= */
    const migrated = ensureDocumentContract(finalDoc);

    /* =========================================
       3. ATUALIZA TAB MANAGER
       ========================================= */
    tabManager.active = migrated;
    tabManager.renderTabs();

    /* =========================================
       4. APLICA DOCUMENTO NO EDITOR
       ========================================= */
    EditorCore.setDocument(migrated);

    /* =========================================
       5. APLICA LINGUAGEM DA ABA ATIVA
       ========================================= */
    if (migrated.language) {
      EditorCore.setLanguage(migrated.language);
      EditorCore.refreshModelLanguage?.();
    }

    /* =========================================
       6. STATUS BAR
       ========================================= */
    statusBar.bindDocument(migrated);

    /* =========================================
       7. RESTAURA CURSOR / SELEÇÃO
       ========================================= */
    const editor = EditorCore.getEditor();
    if (editor && migrated._editorState) {
      const { position, selection } = migrated._editorState;

      if (selection) editor.setSelection(selection);
      if (position) editor.setPosition(position);
    }

    /* =========================================
       8. CURSOR NAVIGATION (1x apenas)
       ========================================= */
    cursorNav.attachToEditor();
    cursorNav.reset();
  };
}