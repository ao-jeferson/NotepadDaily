export function bindEditorActions({
  newTabBtn,
  tabManager,
  smartNewTab,
  activateDocument,
  saveSession,
}) {
  newTabBtn.onclick = () => {
    const doc = smartNewTab.handleNewDocument(
      (name) => tabManager.createNew(name),
    );

    if (doc) {
      activateDocument(doc);
      saveSession();
    }
  };
}
