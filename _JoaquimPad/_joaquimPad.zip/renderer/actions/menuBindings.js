export function bindMenuActions({
  onNewFile,
  onOpenFile,
  onOpenFolder,
  onSaveFile,
  onSaveAsFile,
  onSetLanguage,
}) {
  if (window.menu?.onNewFile && onNewFile) {
    window.menu.onNewFile(() => onNewFile());
  }

  if (window.menu?.onOpenFile && onOpenFile) {
    window.menu.onOpenFile(() => onOpenFile());
  }

  if (window.menu?.onOpenFolder && onOpenFolder) {
    window.menu.onOpenFolder(() => onOpenFolder());
  }

  if (window.menu?.onSaveFile && onSaveFile) {
    window.menu.onSaveFile(() => onSaveFile());
  }

  if (window.menu?.onSaveAsFile && onSaveAsFile) {
    window.menu.onSaveAsFile(() => onSaveAsFile());
  }

  if (window.menu?.onSetLanguage && onSetLanguage) {
    window.menu.onSetLanguage((lang) => onSetLanguage(lang));
  }
}
