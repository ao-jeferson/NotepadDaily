import { resolveDom } from "./init/domBindings.js";
import { bootstrapCore } from "./init/coreBootstrap.js";
import { createDocumentActivator } from "./documents/documentActivation.js";
import { createSessionController } from "./session/sessionController.js";
import { bindMenuActions } from "./actions/menuBindings.js";
import { SmartNewTabFeature } from "../features/smart-new-tab/SmartNewTabFeature.js";
import { CursorNavigationFeature } from "../features/cursor-navigation/CursorNavigationFeature.js";
import { createFileExplorer } from "./explorer/fileExplorerController.js";
import { bindEditorActions } from "./actions/editorActions.js";
import { bindLifecycle } from "./lifecycle/appLifecycle.js";

/* =====================================================
   CONSTANTES
   ===================================================== */

const languageIcons = {
  javascript: "js",
  typescript: "ts",
  python: "python",
  csharp: "csharp",
  java: "java",
  sql: "sql",
  json: "json",
  yaml: "yaml",
  html: "html",
  css: "css",
  plaintext: null,
};

window.createEditor = async () => {
  /* =====================================================
     DOM
     ===================================================== */
  const dom = resolveDom();

  /* =====================================================
     ESTADO GLOBAL
     ===================================================== */
  let projectRoot = null;
  let activeFilePath = null;
  let expandedFolderPaths = new Set();

  /* =====================================================
     CORE
     ===================================================== */
  const { EditorCore, tabManager, fsService, session, statusBar } =
    bootstrapCore(dom, languageIcons);

  /* =====================================================
     FEATURES
     ===================================================== */
  const cursorNav = new CursorNavigationFeature(EditorCore, tabManager);
  cursorNav.init();

  const backBtn = document.getElementById("cursorBack");
  const forwardBtn = document.getElementById("cursorForward");

  const smartNewTab = new SmartNewTabFeature(tabManager, EditorCore);

  cursorNav.onStateChange(({ canGoBack, canGoForward }) => {
    backBtn.disabled = !canGoBack;
    forwardBtn.disabled = !canGoForward;
  });

  backBtn.onclick = () => {
    if (cursorNav.canGoBack()) {
      cursorNav.back();
    }
  };

  forwardBtn.onclick = () => {
    if (cursorNav.canGoForward()) {
      cursorNav.forward();
    }
  };
  /* =====================================================
   CONFIG – SMART NEW TAB
   ===================================================== */

  window.config?.onToggleSmartNewTab((enabled) => {
    smartNewTab.setEnabled(enabled);
  });
  /* =====================================================
     DOCUMENT ACTIVATION
     ===================================================== */
  const activateDocument = createDocumentActivator({
    tabManager,
    fsService,
    EditorCore,
    statusBar,
    cursorNav,
  });
  tabManager.onActivate = activateDocument;

  /* =====================================================
     SESSION
     ===================================================== */
  const sessionController = createSessionController({
    session,
    tabManager,
    EditorCore,
  });

  const saveSession = () =>
    sessionController.save({
      projectRoot,
      expandedFolderPaths,
      activeFilePath,
    });

  /* =====================================================
     FILE EXPLORER
     ===================================================== */
  const fileExplorer = createFileExplorer({
    container: dom.fileExplorer,
    fsService,
    onOpenFile: async (filePath) => {
      const doc = await fsService.openFileFromPath(filePath);
      tabManager.open(doc);
      activateDocument(doc);
      activeFilePath = filePath;
      saveSession();
    },
    onStateChange: (expanded) => {
      expandedFolderPaths = expanded;
      saveSession();
    },
  });

  async function handleOpenFolder() {
    const folder = await window.fs.openFolder();
    if (!folder) return;

    projectRoot = folder;
    expandedFolderPaths = new Set([folder]);

    const tree = await fsService.readDirRecursive(folder);
    fileExplorer.render(tree, Array.from(expandedFolderPaths));

    saveSession();
  }

  /* =====================================================
     RESTORE SESSION  ✅ (AGORA NO LUGAR CERTO)
     ===================================================== */
  const snapshot = session.loadSnapshot();

  if (snapshot) {
    if (snapshot.projectRoot) {
      projectRoot = snapshot.projectRoot;
      expandedFolderPaths = new Set(snapshot.expandedFolders ?? []);

      const tree = await fsService.readDirRecursive(projectRoot);
      fileExplorer.render(tree, Array.from(expandedFolderPaths));
    }

    await tabManager.restoreSnapshot(snapshot);

    /* ========== ACTIVE TAB (REGRAS EXPLÍCITAS) ========== */

    let activeDoc =
      tabManager.tabs.find((t) => t.id === snapshot.activeTabId) ?? null;

    if (activeDoc) {
      let finalDoc = activeDoc;

      // ✅ REGRA 1: filePath tem prioridade absoluta
      if (activeDoc.filePath) {
        try {
          const reopened = await fsService.openFileFromPath(
            activeDoc.filePath,
            { id: activeDoc.id },
          );

          const index = tabManager.tabs.indexOf(activeDoc);
          if (index !== -1) {
            tabManager.tabs[index] = reopened;
            finalDoc = reopened;
          }
        } catch (err) {
          console.warn(
            "Falha ao reabrir arquivo pelo filePath:",
            activeDoc.filePath,
            err,
          );
        }
      }
      // ✅ REGRA 2: sem filePath, mas com conteúdo → documento em memória
      else if (
        activeDoc.filePath == null &&
        typeof activeDoc.getContent === "function" &&
        activeDoc.getContent()
      ) {
        // nada a fazer: o doc já está em memória
        finalDoc = activeDoc;
      }
      // ✅ REGRA 3: sem filePath e sem content
      else {
        console.warn(
          "Documento ativo sem filePath e sem content, ignorando restore:",
          activeDoc,
        );
        finalDoc = null;
      }

      if (finalDoc) {
        tabManager.setActive(finalDoc);

        /* ✅ aplica linguagem correta da aba restaurada */
        if (finalDoc.language) {
          EditorCore.setLanguage(finalDoc.language);
          EditorCore.refreshModelLanguage?.();
        }

        activeFilePath = finalDoc.filePath ?? null;
      }
    }
  }

  if (!tabManager.getActive() && tabManager.tabs.length > 0) {
    tabManager.setActive(tabManager.tabs[0]);
  }

  /* =====================================================
     EDITOR ACTIONS (BOTÕES)
     ===================================================== */
  bindEditorActions({
    newTabBtn: dom.newTabBtn,
    tabManager,
    smartNewTab,
    activateDocument,
    saveSession,
  });

  /* =====================================================
     MENU ACTIONS
     ===================================================== */
  bindMenuActions({
    onOpenFolder: handleOpenFolder,

    onNewFile: () => {
      const doc = tabManager.createNew("Untitled");
      activateDocument(doc);
      saveSession();
    },

    onOpenFile: async () => {
      const filePath = await window.fs.openDialog();
      if (!filePath) return;

      const doc = await fsService.openFileFromPath(filePath);
      tabManager.open(doc);
      activateDocument(doc);
      saveSession();
    },

    onSaveFile: () => {
      const doc = tabManager.getActive();
      if (doc) fsService.save(doc);
    },

    onSaveAsFile: () => {
      const doc = tabManager.getActive();
      if (doc) fsService.saveAs(doc);
    },

    onSetLanguage: (language) => {
      const doc = tabManager.getActive();

      if (!doc) {
        console.warn("Menu Linguagem usado sem aba ativa");
        return;
      }

      doc.language = language;
      doc.languageManuallySet = true;

      EditorCore.setLanguage(language);
      EditorCore.refreshModelLanguage?.();

      tabManager.renderTabs();
      statusBar.bindDocument(doc);

      saveSession();
    },
  });

  /* =====================================================
     LIFECYCLE
     ===================================================== */
  bindLifecycle(saveSession);
  function refreshFileExplorerHighlight() {
    document.querySelectorAll(".explorer-item.file").forEach((li) => {
      li.classList.toggle("active-file", li.dataset.path === activeFilePath);
    });
  }
};
