module.exports = {
  testDir: './tests/e2e',
  timeout: 60_000,
  use: {
    channel: 'chrome',   // ✅ usa Chrome instalado
    headless: true,
  },
};