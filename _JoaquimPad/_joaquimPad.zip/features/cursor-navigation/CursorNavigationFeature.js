// features/cursor-navigation/CursorNavigationFeature.js

export class CursorNavigationFeature {
  constructor(EditorCore, tabManager) {
    this.EditorCore = EditorCore;
    this.tabManager = tabManager;

    this.backStack = [];
    this.forwardStack = [];

    this.isNavigating = false;
    this.onStateChangeCallback = null;

    this._cursorDisposable = null;
  }

  /* =========================
     INIT
     ========================= */
  init() {
    this.attachToEditor();
  }

  /* =========================
     LISTENER ÚNICO
     ========================= */
  attachToEditor() {
    const editor = this.EditorCore.getEditor();
    if (!editor) return;

    // ✅ remove listener anterior corretamente
    this._cursorDisposable?.dispose();

    this._cursorDisposable = editor.onDidChangeCursorPosition((e) => {
      if (this.isNavigating) return;

      const activeDoc = this.tabManager.getActive?.();
      if (!activeDoc) return;

      const entry = {
        docId: activeDoc.id,
        position: e.position,
      };

      const last = this.backStack[this.backStack.length - 1];

      // evita duplicação ruidosa
      if (
        last &&
        last.docId === entry.docId &&
        last.position.lineNumber === entry.position.lineNumber &&
        last.position.column === entry.position.column
      ) {
        return;
      }

      this.backStack.push(entry);
      this.forwardStack = []; // ✅ padrão de navegação
      this.emitState();
    });
  }

  /* =========================
     STATE
     ========================= */
  reset() {
    this.backStack = [];
    this.forwardStack = [];
    this.emitState();
  }

  canGoBack() {
    return this.backStack.length > 1;
  }

  canGoForward() {
    return this.forwardStack.length > 0;
  }

  /* =========================
     BACK
     ========================= */
  back() {
    if (!this.canGoBack()) return;

    this.isNavigating = true;

    const current = this.backStack.pop();
    this.forwardStack.push(current);

    const target = this.backStack[this.backStack.length - 1];
    this.navigate(target);

    this.isNavigating = false;
    this.emitState();
  }

  /* =========================
     FORWARD
     ========================= */
  forward() {
    if (!this.canGoForward()) return;

    this.isNavigating = true;

    const target = this.forwardStack.pop();
    this.backStack.push(target);

    this.navigate(target);

    this.isNavigating = false;
    this.emitState();
  }

  /* =========================
     NAVIGATE
     ========================= */
  navigate(entry) {
    if (!entry) return;

    const active = this.tabManager.getActive();

    if (!active || active.id !== entry.docId) {
      const targetDoc = this.tabManager.tabs.find(
        (d) => d.id === entry.docId
      );
      if (!targetDoc) return;

      this.tabManager.setActive(targetDoc);
      this.attachToEditor(); // ✅ troca de model
    }

    const editor = this.EditorCore.getEditor();
    if (!editor) return;

    editor.setPosition(entry.position);
    editor.revealPositionInCenter(entry.position);
    editor.focus();
  }

  /* =========================
     UI STATE
     ========================= */
  onStateChange(cb) {
    this.onStateChangeCallback = cb;
  }

  emitState() {
    this.onStateChangeCallback?.({
      canGoBack: this.canGoBack(),
      canGoForward: this.canGoForward(),
    });
  }
}