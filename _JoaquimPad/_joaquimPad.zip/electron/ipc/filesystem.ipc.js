const { ipcMain } = require("electron");
const fs = require("fs/promises");
const path = require("path");

ipcMain.handle("fs:readDir", async (_, dirPath) => {
  const entries = await fs.readdir(dirPath, { withFileTypes: true });

  return entries.map(entry => ({
    name: entry.name,
    path: path.join(dirPath, entry.name),
    type: entry.isDirectory() ? "folder" : "file",
  }));
});
