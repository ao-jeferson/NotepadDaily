# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs\tabs.spec.js >> cria, alterna, fecha e restaura abas corretamente
- Location: tests\e2e\specs\tabs.spec.js:4:1

# Error details

```
Error: expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 1
Received:    0
```

# Test source

```ts
  1  | const { test, expect } = require('@playwright/test');
  2  | const { launchApp } = require('../setup/electronApp');
  3  | 
  4  | test('cria, alterna, fecha e restaura abas corretamente', async () => {
  5  |   let { app, page } = await launchApp({
  6  |     initScript: () => {
  7  |       localStorage.removeItem('editor.session.v1');
  8  |     },
  9  |   });
  10 | 
  11 |   /* =========================
  12 |      ESTADO INICIAL
  13 |      ========================= */
  14 |   let tabs = page.locator('#tabs .tab');
  15 |   const initialCount = await tabs.count();
  16 | 
  17 |   // ✅ SEMPRE >= 1
> 18 |   expect(initialCount).toBeGreaterThanOrEqual(1);
     |                        ^ Error: expect(received).toBeGreaterThanOrEqual(expected)
  19 | 
  20 |   /* =========================
  21 |      CRIA NOVA ABA
  22 |      ========================= */
  23 |   await page.click('#newTabBtn');
  24 | 
  25 |   tabs = page.locator('#tabs .tab');
  26 |   await expect(tabs).toHaveCount(initialCount + 1);
  27 |   await expect(tabs.last()).toHaveClass(/active/);
  28 | 
  29 |   /* =========================
  30 |      CRIA OUTRA ABA
  31 |      ========================= */
  32 |   await page.click('#newTabBtn');
  33 | 
  34 |   tabs = page.locator('#tabs .tab');
  35 |   await expect(tabs).toHaveCount(initialCount + 2);
  36 |   await expect(tabs.last()).toHaveClass(/active/);
  37 | 
  38 |   /* =========================
  39 |      ALTERNA PARA ABA ANTERIOR
  40 |      ========================= */
  41 |   await tabs.nth(initialCount).click();
  42 |   await expect(tabs.nth(initialCount)).toHaveClass(/active/);
  43 | 
  44 |   /* =========================
  45 |      FECHA ABA ATIVA
  46 |      ========================= */
  47 |   await tabs.nth(initialCount).locator('.close').click();
  48 | 
  49 |   tabs = page.locator('#tabs .tab');
  50 |   await expect(tabs).toHaveCount(initialCount + 1);
  51 | 
  52 |   /* =========================
  53 |      FECHA APP
  54 |      ========================= */
  55 |   await app.close();
  56 | 
  57 |   /* =========================
  58 |      SEGUNDA EXECUÇÃO (RESTORE)
  59 |      ========================= */
  60 |   ({ app, page } = await launchApp());
  61 | 
  62 |   tabs = page.locator('#tabs .tab');
  63 |   await expect(tabs).toHaveCount(initialCount + 1);
  64 | 
  65 |   await app.close();
  66 | });
```