const { contextBridge, ipcRenderer, webFrame } = require("electron");

/* =====================================================
   ZOOM (Ctrl + Scroll)
   ===================================================== */

const MIN_ZOOM = -2;
const MAX_ZOOM = 3;

window.addEventListener(
  "wheel",
  (e) => {
    if (!e.ctrlKey) return;

    e.preventDefault();

    let zoom = webFrame.getZoomLevel();
    zoom += e.deltaY < 0 ? 0.1 : -0.1;
    zoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, zoom));

    webFrame.setZoomLevel(zoom);
  },
  { passive: false },
);

/* =====================================================
   FILE SYSTEM (IPC ONLY)
   ===================================================== */

contextBridge.exposeInMainWorld("fs", {
  openDialog: () => ipcRenderer.invoke("fs:open-dialog"),
  openFolder: () => ipcRenderer.invoke("fs:open-folder"),
  saveDialog: () => ipcRenderer.invoke("fs:save-dialog"),

  readFile: (path) => ipcRenderer.invoke("fs:readFile", path),
  writeFile: (path, content) =>
    ipcRenderer.invoke("fs:writeFile", path, content),

  stat: (path) => ipcRenderer.invoke("fs:stat", path),
  readFirstBytes: (path, maxBytes) =>
    ipcRenderer.invoke("fs:readFirstBytes", path, maxBytes),
  readDir: (path) => ipcRenderer.invoke("fs:readDir", path),
});

/* =====================================================
   MENU – EVENTS (MAIN → RENDERER)
   ===================================================== */

contextBridge.exposeInMainWorld("menu", {
  onNewFile: (cb) => ipcRenderer.on("menu:file:new", cb),
  onOpenFile: (cb) => ipcRenderer.on("menu:file:open", cb),
  onOpenFolder: (cb) => ipcRenderer.on("menu:file:openFolder", cb),
  onSaveFile: (cb) => ipcRenderer.on("menu:file:save", cb),
  onSaveAsFile: (cb) => ipcRenderer.on("menu:file:saveAs", cb),
  onCloseTab: (cb) => ipcRenderer.on("menu:file:closeTab", cb),

  onSetLanguage: (cb) =>
    ipcRenderer.on("menu:view:setLanguage", (_, language) => cb(language)),
});

/* =====================================================
   MENU / COMMANDS – ACTIONS (RENDERER → MAIN)
   ===================================================== */

contextBridge.exposeInMainWorld("commands", {
  setLanguage: (language) =>
    ipcRenderer.send("menu:view:setLanguage", language),
});

/* =====================================================
   CONFIG
   ===================================================== */

contextBridge.exposeInMainWorld("config", {
  onToggleSmartNewTab: (cb) =>
    ipcRenderer.on("config:smart-new-tab", (_, value) => cb(value)),
});

/* =====================================================
   LIFECYCLE
   ===================================================== */

contextBridge.exposeInMainWorld("appLifecycle", {
  onBeforeQuit: (cb) => ipcRenderer.on("app:before-quit", cb),
});
